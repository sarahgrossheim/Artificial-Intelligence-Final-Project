# Sarah Grossheim
# CS470 Final Project
# This is a project that will take in a CSV file with song names, artists,
# genre, and moods. You will enter in a genre, and mood, and the program
# will output three songs based on the mood.

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import random
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import LabelEncoder
from tkinter import *

################################### Label Encoding ###############################

# Read CSV file and ignore header by skipping row 1
data = pd.read_csv('songs.csv', header=None, skiprows=1)

# Store the 1st and 2nd columns (title & artist) into lists
# .values ignore the columns and rows and puts it into 2d array
titleAndArtist = data.iloc[:,[0,1]].values

# Store the 3rd and 4th columns (mood & genre) into lists
# .values ignore the columns and rows and puts it into 2d array
genre = data.iloc[:, 2].values
mood = data.iloc[:,3].values

# Use the label encoder method to convert the grades to numbers
# label_encoder object knows how to understand word labels
label_encoder = LabelEncoder()

# Encode the mood and genre labels
genre = label_encoder.fit_transform(genre)
mood = label_encoder.fit_transform(mood)

# Combine genre and mood into one 2D array
genreAndMood = np.column_stack((genre, mood))

"""
# Print the encoded data 
for i in range (len(titleAndArtist)):
    print("Title:", titleAndArtist[i][0])
    print("Artist:", titleAndArtist[i][1])
    print("Genre:", genreAndMood[i][0])
    print("Mood:", genreAndMood[i][1])
"""
############################# End Label Encoding ###############################
############################### References #####################################

# The majority of this code is from my Assignment #7(Plotting and Classification)
# Specifically, the classRoster.py

# This is how I learned how to turn two 2d arrays into a stacked 2d array
# https://numpy.org/doc/stable/reference/generated/numpy.column_stack.html

# This is how the data gets encoded:
# Mood:
# 0 = Angry (138)
# 1 = Breakup (56) 
# 2 = Happy (178)
# 3 = Lonely (42) 
# 4 = Love (230) 
# 5 = Party (312) 
# 6 = Sad (268) 
# 7 = Vibey (302)

# Genre:
# 0 = Alternative (293)
# 1 = Alternative Folk (1)
# 2 = Alternative Rap (15)
# 3 = Ambient (1)
# 4 = Blues (1)
# 5 = Christian (1)
# 6 = Country (48)
# 7 = Dance (6)
# 8 = Dirty South (1)
# 9 = Disco (1)
# 10 = EMO (2)
# 11 = Electronic (5)
# 12 = Folk (1)
# 13 = Funk (1)
# 14 = Gospel (1)
# 15 = Hard Rock (69)
# 16 = Heavy Metal (1)
# 17 = Hip-Hop (50)
# 18 = Hip-Hop/Rap (466)
# 19 = Indie Pop (6)
# 20 = Indie Rock (15)
# 21 = Jazz (3)
# 22 = Metal (35)
# 23 = Pop (194)
# 24 = Punk (7)
# 25 = R&B/Soul (104)
# 26 = Rap (14)
# 27 = Reggae (1)
# 28 = Rock (152)
# 29 = Singer/Songwriter (18)
# 30 = Soul (1)
# 31 = Soundtrack (8)
# 32 = Traditional Folk (1)
# 33 = Urbano latino (1)
# 34 = Vocal (2)
################ Recommend Function & Nearest Neighbor Clustering #################################
def recommend():
    # Get user values from spin box (typecast to int)
    userMood = int(spMood.get())
    userGenre = int(spGenre.get())
    
    # Reshape them to become a 2d array
    userMood = np.array([userMood]).reshape(-1,1)
    userGenre = np.array([userGenre]).reshape(-1,1)

    # Test datapoint and reshape to fit the model
    test_datapoint = np.concatenate((userGenre, userMood), axis=1)
    test_datapoint = test_datapoint.reshape(1,-1)

    # Number of nearest neighbors
    # Depending on what mood you are going to pick, use the total number of songs in each mood
    # Ex: Angry = 138, Breakup = 56, Happy = 178, Lonely = 42, Love = 230, Party = 312, Sad = 268, Vibey = 302
    # This is important
    k = 56

    # Build K Nearest Neighbors model
    knn_model = NearestNeighbors(n_neighbors=k, algorithm='ball_tree').fit(genreAndMood)
    distances, indices = knn_model.kneighbors(test_datapoint)

################# If there are not enough songs with the same mood and genre, #####################​
################### recommend songs with the same mood, but different genre. ######################​
    # Get the indices of songs with the same mood and genre
    # Put the indices into sameMoodAndGenre
    sameMoodAndGenre = []
    for i in indices[0]:
        # Check if the genre and mood match user's input
        if genreAndMood[i][0] == userGenre[0][0] and genreAndMood[i][1] == userMood[0][0]:
            # If yes, add it to the list of songs with same mood and genre
            sameMoodAndGenre.append(i)

    # Calculate how many additional songs are needed to fit the same mood, regardless of genre
    additionalSongs = k - len(sameMoodAndGenre)

    # If there are not enough songs with the same mood and genre,
    # recommend songs with the same mood, but different genre
    if additionalSongs > 0:
        sameMoodDiffGenre = []
        # Iterate through songs to find ones with same mood, but different genre
        for i, moodGenre in enumerate(genreAndMood):
            # Find the songs with the same mood but different genre
            if moodGenre[1] == userMood[0][0] and i not in sameMoodAndGenre:
                # Add it to the list of songs with same mood and diff genre
                sameMoodDiffGenre.append(i)
                # When enough additional songs are added, break out of the loop
                if len(sameMoodDiffGenre) == additionalSongs:
                    break

    # Fill up the k recommended indices with new indices that were calculated above
    indices[0][len(sameMoodAndGenre):] = sameMoodDiffGenre

    # Shuffle the indices to get different recommendations
    random.shuffle(indices[0])
######################################### END #######################################################​

    # Create labels in GUI for song recommendations
    labelSongRec = Label(window, text = "Song Recommendations:", bg = "purple", fg = "white",width = 10)
    labelSongRec.grid(row=4, column=0, padx=10, pady=10, columnspan=2, sticky=W+E)

    # Create label and entry box for song 1
    labelSong1 = Label(window, text = "Song 1:", bg = "purple", fg="white", width = 10)
    labelSong1.grid(row=5, column=0, padx=5, pady=10, sticky=W+E)
    entrySong1 = Entry(window, width=70, state="normal")
    entrySong1.grid(row=5, column=1, padx=5, pady=10, sticky=W+E)
    
    # Create label and text box for song 2
    labelSong2 = Label(window, text = "Song 2:", bg = "purple", fg="white", width = 10)
    labelSong2.grid(row=6, column=0, padx=5, pady=10, sticky=W+E)
    entrySong2 = Entry(window, width=70, state="normal")
    entrySong2.grid(row=6, column=1, padx=5, pady=10, sticky=W+E)
    
    # Create label and text box for song 3
    labelSong3 = Label(window, text = "Song 3:", bg = "purple", fg="white", width = 10)
    labelSong3.grid(row=7, column=0, padx=5, pady=10, sticky=W+E)
    entrySong3 = Entry(window, width=70, state="normal")
    entrySong3.grid(row=7, column=1, padx=5, pady=10, sticky=W+E)
    
    # Print the 'k' nearest neighbors and put into the song entry boxes
    for rank, index in enumerate(indices[0][:k], start=1):
        songInfo = f"{titleAndArtist[index][0]} - {titleAndArtist[index][1]}"
        if rank == 1:
            entrySong1.insert(END, songInfo)
        elif rank == 2:
            entrySong2.insert(END, songInfo)
        elif rank == 3:
            entrySong3.insert(END, songInfo)
        print(str(rank) + " ==>", titleAndArtist[index])

    # Visualize the nearest neighbors along with the test datapoint 
    plt.figure()
    plt.title('Nearest neighbors')
    plt.scatter(genreAndMood[:, 0], genreAndMood[:, 1], marker='o', s=75, color='k')
    plt.scatter(genreAndMood[indices][0][:][:, 0], genreAndMood[indices][0][:][:, 1], 
        marker='o', s=250, color='k', facecolors='none')

    # Show the graph
    plt.show()

############## End Recommend Function & Nearest Neighbor Clustering ############
################################ References ####################################
    
# This code came from the K_nearest_neighbors file from Lesson 13

# This is how I learned how to reshape and concatenate my data
# https://saturncloud.io/blog/understanding-the-differences-between-numpy-reshape1-1-and-reshape1-1/
# https://www.geeksforgeeks.org/numpy-concatenate-function-python/

# This is how I learned to see if something was in a list or not
# https://www.tutorialspoint.com/list-methods-in-python-in-not-in-len-min-max

#################################### GUI #######################################
# Setup window
window = Tk()
window.title("Music Suggestion System")
window.geometry("525x500")
window["bg"] = "Orange"

# Create title label
title = Label(window, text="Music Suggestion System", fg="white", bg="purple", font="50")
title.grid(row=0, column=0, columnspan=2, padx=10, pady=5, sticky=W)

# Create labels and spin boxes for genre
labelGenre = Label(window, text="Genre:", fg="white", bg="purple")
labelGenre.grid(row=1, column=0, padx=10, pady=5, sticky=W)
spGenre = Spinbox(window, fg="white", bg="purple", from_=0, to=34, increment=1, width=10)
spGenre.grid(row=1, column=1, padx=10, pady=5, sticky=W)

# Create labels and spin boxes for mood
labelMood = Label(window, text="Mood:", fg="white", bg="purple")
labelMood.grid(row=2, column=0, padx=10, pady=5, sticky=W)
spMood = Spinbox(window, fg="white", bg="purple", from_=0, to=7, increment=1, width=10)
spMood.grid(row=2, column=1, padx=10, pady=5, sticky=W)
    
# Create button to generate songs
buttonSongs = Button(window, text="Generate Songs", fg="white", bg="purple", command=recommend)
buttonSongs.grid(row=3, column=0, columnspan=2, padx=10, pady=10, sticky=W+E)

# Create list that shows the mood
label = Label(window, fg="white",text = "Mood", bg = "purple")
label.grid(row=0, column=2, padx=10, pady=5, sticky=N+S)
listbox = Listbox(window, bg="purple", fg="white", height=8)
listbox.grid(row=1, column=2, padx=10, pady=5, sticky=N+S+E)

# Create list that shows the genre
label2 = Label(window, fg="white", text="Genre", bg="purple")
label2.grid(row=0, column=3, padx=10, pady=5, sticky = N+S)
listbox2 = Listbox(window, bg="purple", fg="white", height=8)
listbox2.grid(row=1, column=3, padx=10, pady=5, sticky=N+S+E)

# Create scrollbar for genre listbox
scrollbar = Scrollbar(window, command=listbox2.yview)
scrollbar.grid(row=1, column=4, sticky=N+S)
listbox2.config(yscrollcommand=scrollbar.set)

#Insert moods into list
listbox.insert(1, "0 - Angry")
listbox.insert(2, "1 - Breakup")
listbox.insert(3, "2 - Happy")
listbox.insert(4, "3 - Lonely")
listbox.insert(5, "4 - Love")
listbox.insert(6, "5 - Party")
listbox.insert(7, "6 - Sad")
listbox.insert(8, "7 - Vibey")

#Insert genres into list
listbox2.insert(1, "0 - Alternative")
listbox2.insert(2, "1 - Alternative Rock")
listbox2.insert(3, "2 - Alternative Rap")
listbox2.insert(4, "3 - Ambient")
listbox2.insert(5, "4 - Blues")
listbox2.insert(6, "5 - Christian")
listbox2.insert(7, "6 - Country")
listbox2.insert(8, "7 - Dance")
listbox2.insert(9, "8 - Dirty South")
listbox2.insert(10, "9 - Disco")
listbox2.insert(11, "10 - EMO")
listbox2.insert(12, "11 - Electronic")
listbox2.insert(13, "12 - Folk")
listbox2.insert(14, "13 - Funk")
listbox2.insert(15, "14 - Gospel")
listbox2.insert(16, "15 - Hard Rock")
listbox2.insert(17, "16 - Heavy Metal")
listbox2.insert(18, "17 - Hip-Hop")
listbox2.insert(19, "18 - Hip-Hop/Rap")
listbox2.insert(20, "19 - Indie Pop")
listbox2.insert(21, "20 - Indie Rock")
listbox2.insert(22, "21 - Jazz")
listbox2.insert(23, "22 - Metal")
listbox2.insert(24, "23 - Pop")
listbox2.insert(25, "24 - Punk")
listbox2.insert(26, "25 - R&B/Soul")
listbox2.insert(27, "26 - Rap")
listbox2.insert(28, "27 - Reggae")
listbox2.insert(29, "28 - Rock")
listbox2.insert(30, "29 - Singer/Songwriter")
listbox2.insert(31, "30 - Soul")
listbox2.insert(32, "31 - Soundtrack")
listbox2.insert(33, "32 - Traditional Folk")
listbox2.insert(34, "33 - Urbano Latino")
listbox2.insert(35, "34 - Vocal")

#Infinite loop that waits for events to occur
window.mainloop()

################################# End GUI ######################################
################################ References ####################################

# Some of this GUI code came from Mrs. Etheredge's CS101 class

# This is how I learned to make a spin box
# https://www.geeksforgeeks.org/python-tkinter-spinbox/?ref=lbp

# This is how I learned to make a list box
# https://www.geeksforgeeks.org/python-tkinter-listbox-widget/?ref=lbp

# This is how I learned to use sticky
# https://www.pythonguis.com/tutorials/create-ui-with-tkinter-grid-layout-manager/#:~:text=columnspan%20%2C%20rowspan%20%2D%2D%20specifies%20how,spacing%20right%20for%20your%20widgets.&text=sticky%20%2D%2D%20specifies%20a%20value%20of,NE%20%2C%20SW%20%2C%20or%20SE%20.
# https://www.oreilly.com/library/view/python-in-a/0596001886/re701.html

# This is how I learned to make a scroll bar
# https://www.geeksforgeeks.org/python-tkinter-scrollbar/?ref=lbp
# https://www.tutorialspoint.com/python/tk_scrollbar.htm
